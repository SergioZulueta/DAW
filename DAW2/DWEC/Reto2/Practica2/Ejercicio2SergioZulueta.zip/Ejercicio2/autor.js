class Autor {
    constructor(dni, nombreApellidos) {
        this.dni = dni;
        this.nombreApellidos = nombreApellidos;
    }
}


let autores = [new Autor("12807129Q", "Sergio Zulueta"), new Autor("79767288E", "Iñaki Caballero"),
    new Autor("03145950X", "Miguel Barros")];